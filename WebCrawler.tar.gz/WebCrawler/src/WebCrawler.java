
import pl.edu.agh.kis.*;
import java.net.URL;
import java.util.List;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import pl.edu.agh.kis.*;

	public class WebCrawler extends Thread{

		private static WWWPageDownloader pageDownloader;
		private static DownloadQueue pagesToVisit;
		private static VisitedPages visitedPages;
		static Logs log;
		
		public WebCrawler(String startURL) throws DownloaderException{
			pageDownloader = new PageDownloader();
			//pageDownloader = new PageDownloaderSocket();
			try{
			//	pagesToVisit = new QueueOfPage();
				pagesToVisit = new PageInFile();
				pagesToVisit.addPage(new URL(startURL));
			}catch(MalformedURLException e){
				throw new DownloaderException("MalformedException");
			}
			visitedPages = new IfVisitedPages();
			log = MiniLog.getLogsContainer("Komunikaty/log.txt");
		}
		
		private String getContentsPage(String URL){
			try{
				return pageDownloader.downloadPage(URL);
			}catch(DownloaderException e){
				return null;
			}
		}
		
		List<String> link(String stream) {
			String regex = "<[aA] [^>]*[hH][rR][eE][fF]=\"([^\"]+)\"";
			List<String> newLinks = new ArrayList<String>();
			Pattern pattern = Pattern.compile(regex);
			Matcher m = pattern.matcher(stream);
			int counter = 0;
			while (m.find()) {
				if (counter > 3){
					newLinks.add(m.group(1));
				}
				counter++;
			}
			return newLinks;
		}

	    private List<String> findLinksFromPage(String page) {
	        page = getContentsPage(page);
	        if (page != null){
	        	return link(page);
	        }
	        return null;
	    }

	    private URL fixLink(String original, String notFixedLink) throws DownloaderException {
	    	
	        URL fixedLink;

	        if (notFixedLink.length() < 7 || !notFixedLink.substring(0,4).equals("http")){
	            StringBuilder sb = new StringBuilder(original);
	            sb.append(notFixedLink);
	            try {
	                fixedLink = new URL(sb.toString());
	            }
	            catch (MalformedURLException e){
	                throw new DownloaderException("MALFORMEDURLException: I can't fix your link");
	            }

	        }
	        else {
	            try{
	                fixedLink = new URL(notFixedLink);
	            }
	            catch (MalformedURLException e){
	                throw new DownloaderException("MALFORMEDURLException: I can't fix your link");
	                
	            }
	        }

	        return fixedLink;
	    }

	    private synchronized void addToAlreadyVisited(URL correctURL) {
	    	if (visitedPages.pageAlreadyVisited(correctURL) == false){
                pagesToVisit.addPage(correctURL);
                log.addInfo("New page to visited:  "  + correctURL);
            }
	        try{
	            Thread.sleep(2);
	        } catch (Exception e) {
	              System.err.println("Thread has problem Interrupted ");  
	        }
	   }

	    private synchronized URL getNextPage(){
	    	if (pagesToVisit.isEmpty() == false){
	    		URL url = pagesToVisit.getNextPage();
	    		return url;
	    	}
	    	try{
	    		Thread.sleep(2);
	    	}catch(Exception e){
	    		System.err.println("Thread has problem Interrupted ");  
	    	}
	    	return null;
	    }
	    
	    public void run() {
	    	
	    	log.addError("Liczba stron w kolejce: " + pagesToVisit.getSize());
	        while (pagesToVisit.isEmpty() == false) {
	            URL url = getNextPage();
	            if (url == null){
	            	continue;
	            }
	            log.addWarning("The website: " + url + " is visitting now ");
	            visitedPages.addVisitedPage(url);
	            String urlInString = url.toString();
	            
	            List<String> newLinks = findLinksFromPage(urlInString);
	            if (newLinks == null) {
	            	continue;
	            }
	            for (String link : newLinks) {
	                try {
	                    URL correctURL = fixLink(urlInString, link);
	                    addToAlreadyVisited(correctURL);                    
	                } catch (DownloaderException e) {
	                    System.out.println(e);
	                    continue;
	                }

	            }
	           if (pagesToVisit.getSize() > 100){
	        	   break;
	           }
	        }
	        log.writeStatementToFile();
	    }

}
