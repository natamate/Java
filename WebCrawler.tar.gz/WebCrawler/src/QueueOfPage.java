
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


class QueueOfPage implements DownloadQueue{
	private static Queue<URL> queueWithPages = new LinkedList<URL>();
	
	public boolean contains(URL pageURL){
		if (queueWithPages.contains(pageURL) == true){
			return true;
		}
		else{
			return false;
		}
	}
	
	public Queue<URL> getQueueWithPages(){
		return queueWithPages;
	}
	
	public void addPage(URL pageURL){
		if (contains(pageURL) == false){
			queueWithPages.add(pageURL);
		}
	}
	
	public boolean isEmpty(){
		if (queueWithPages.isEmpty() == true){
			return true;
		}
		else{
			return false;
		}
	}

	public URL getNextPage(){
		return queueWithPages.poll();
	}
	
	public int getSize(){
		return queueWithPages.size();
	}
	@Override
	public String toString(){
		String result = "";
		for (URL url : queueWithPages){
			result += url;
		}
		return result;
	}

}
