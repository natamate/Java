
public class Main {

	public static void main(String[] args) {
		try{
			WebCrawler crawler = new WebCrawler("http://www.interia.pl");
			crawler.start();
		}catch(DownloaderException e){
			System.out.println(e);
		}
	}

}
