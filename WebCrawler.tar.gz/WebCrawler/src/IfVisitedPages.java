import java.net.URL;
import java.util.HashSet;
import java.util.Set;

public class IfVisitedPages implements VisitedPages{

	private static Set<URL> visitedPages = new HashSet<URL>();
	
	public boolean pageAlreadyVisited(URL pageURL){
		if (visitedPages.contains(pageURL) == true){
			return true;
		}
		else{
			return false;
		}
	}

    public void addVisitedPage(URL pageURL){
    	if (pageAlreadyVisited(pageURL) == false){
    		visitedPages.add(pageURL);
    	}
    }
    
    @Override
    public String toString(){
    	String result = "";
    	for (URL url : visitedPages){
    		result += url + "\n";
    	}
    	return result;
    }
}
