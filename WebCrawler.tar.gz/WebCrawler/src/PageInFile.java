import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.org.apache.xerces.internal.impl.io.MalformedByteSequenceException;

public class PageInFile implements DownloadQueue {

	private String pathToFile = "VisitedWeb.txt";

	public void setPath(String newPathToFile) {
		pathToFile = newPathToFile;
	}

	public PageInFile() {
		try {
			File file = new File(pathToFile);
			if (file.createNewFile()) {
				System.out.println("The file is created");
			} else {
				System.out.println("The file already existed");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void add(String newPage) {
		File file = new File(pathToFile);
		try {
			FileWriter out = new FileWriter(file.getAbsoluteFile(), true);
			PrintWriter writer = new PrintWriter(out);
			writer.println(newPage);
			writer.close();
		} catch (IOException e) {
			System.out.println("Cannot append to file");
		}
		System.out.println("Write is done");
	}

	public List<String> getURL() {
		List<String> listURL = new ArrayList<String>();
		String line = "";
		FileReader reader = null;

		try {
			reader = new FileReader(pathToFile);

		} catch (FileNotFoundException e) {
			System.out.println("File with path: " + pathToFile + " not found");
		}

		BufferedReader bufferReader = new BufferedReader(reader);

		try {
			while ((line = bufferReader.readLine()) != null) {
				listURL.add(line);
				// System.out.println(link(line));
			}
		} catch (IOException e) {
			System.out
					.println("public boolean checkIsVisited(String searchPage) Errors with read from file");
		}

		return listURL;
	}

	public String link(String stream) {
		String regex = "<[aA] [^>]*[hH][rR][eE][fF]=\"([^\"]+)\"";
		Pattern pattern = Pattern.compile(regex);
		Matcher m = pattern.matcher(stream);
		boolean b = m.matches();
		StringBuilder result = new StringBuilder();
		int counter = 0;
		while (m.find()) {
			if (counter > 3)
				result.append(m.group(1) + "\n");

			// linksToVisit.add(m.group(1));
			counter++;
		}
		return result.toString();
	}

	public void clear() {
		File file = new File(pathToFile);
		if (file.delete()) {
			System.out.println(file.getName() + " is deleted");
		} else {
			System.out.println(" File isn't deleted please try again");
		}
	}

	@Override
	public void addPage(URL pageURL) {
		add(pageURL.toString());
	}

	@Override
	public boolean isEmpty() {
		List<String> allURL = getURL();
		if (allURL.isEmpty() == true || allURL == null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public URL getNextPage() {
		List<String> allURL = getURL();
		URL url = null;
		try {
			url = new URL(allURL.get(0));
		} catch (MalformedURLException e) {
			WebCrawler.log.addError("Malformed Exception, incorrect URL");
		}
		return url;
	}

	@Override
	public int getSize() {
		List<String> allURL = getURL();
		int size = 0;
		for (String url : allURL){
			size++;
		}
		return size;
	}

}
