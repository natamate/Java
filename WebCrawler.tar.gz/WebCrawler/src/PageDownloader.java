import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class PageDownloader implements WWWPageDownloader {

	public String downloadPage(String pageURL) throws DownloaderException {
		StringBuilder result = new StringBuilder();

		try {
			URL oracle = new URL(pageURL);

			URLConnection dbConnection = oracle.openConnection();

			BufferedReader in = new BufferedReader(new InputStreamReader(
					dbConnection.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				result.append(inputLine + "\n");
				System.out.println(inputLine);
			}
			in.close();
			BufferedReader stdin = new BufferedReader(new InputStreamReader(
					System.in));
			
		} catch (IOException e) {
			DownloaderException io = new DownloaderException("IOEXCEPTION \n");
			System.out.println(io.catchIO());
		} catch(Exception e){
			DownloaderException io = new DownloaderException("URL is an incorrect \n");
			System.out.println(io.notFindPage());
		}

		return result.toString();
	}
	
}
