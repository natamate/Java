import static org.junit.Assert.*;

import org.junit.Test;


public class WebCrawlerTest {
	
	@Test
	public void testRun() {
		fail("Not yet implemented");
	}

	@Test
	public void testWebCrawler() {
		try{
			WebCrawler crawler = new WebCrawler("http://www.onet.pl/");
			assertTrue(true);
		}catch(DownloaderException e){
			fail("URL is correct");
		}
		try{
			WebCrawler crawler2 = new WebCrawler("something wrong");
			fail();
		}catch(DownloaderException e){
				assertTrue(true);
			}
		
	}

	@Test
	public void testLink() {
		try{
			WebCrawler crawler = new WebCrawler("http://www.onet.pl/");
			if (crawler.link(" ") != null){
				fail("link doesn't work");
			}
			assertTrue(true);
		}catch(DownloaderException e){
			e.printStackTrace();
		}
	}

	@Test
	public void testAddToAlreadyVisited() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNextPage() {
		fail("Not yet implemented");
	}

}
