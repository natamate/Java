import static org.junit.Assert.*;

import java.net.URL;

import org.junit.Test;


public class PageDownloaderTest {

	@Test
	public void testDownloadPage() {
		PageDownloader test = new PageDownloader();
		try{
			if (test.downloadPage("SOmething wrong") == null){
				fail("Something wron cause URL is incorrect");
			}
		}catch(DownloaderException e){
			System.out.println("Incorrect URL");
		}
		try{
			if (test.downloadPage("http://upel.agh.edu.pl/weaiib/course/view.php?id=299") == null){
				fail("The contents of page is null");
			}
		}catch(DownloaderException e){
			
		}
	}

}
