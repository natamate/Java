import static org.junit.Assert.*;

import java.net.URL;

import org.junit.Test;


public class QueueOfPageTest {
	QueueOfPage test = new QueueOfPage();

	@Test
	public void testContains() {
		try{
			test.addPage(new URL("http://upel.agh.edu.pl/weaiib/course/view.php?id=299"));
			if (test.contains(new URL("http://upel.agh.edu.pl/weaiib/course/view.php?id=299")) == false){
				fail("Contains wasn't found added page");
			}
			test.addPage(new URL("something wrong"));
			if (test.contains(new URL("something wrong")) == true){
				fail("It added wrong url!");
			}
		}catch(Exception e){
			
		}
		//fail("Not yet implemented");
	}

	@Test
	public void testAddPage() {
		//QueueOfPage test = new QueueOfPage();
		try{
			test.addPage(new URL("cos tam"));
		}catch(Exception e){
			
		}
		if (test.getQueueWithPages().contains("costam") == true){
			fail("The incorrect URL was added to queue");
		}else{
			
		}
		//fail("Not yet implemented");
	}

	@Test
	public void testIsEmpty() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNextPage() {
		if (test.isEmpty() == true){
			if (test.getNextPage() != null){
				fail("Something goes wrong with getNextPage");
			}
		}else{
			if (test.getNextPage() == null){
				fail("The queue isn't empty and return null");
			}
		}
		//fail("Not yet implemented");
	}

	@Test
	public void testGetSize() {
		if (test.getSize() == 0){
			if (test.getNextPage() != null){
				fail("The getSize doesn't work");
			}
		}else{
			if (test.getNextPage() == null){
				fail("The getSize doesn't work");
			}
		}
		//fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
