package pl.edu.agh.kis;

/** 
 * Wyliczenie generujace poziom waznosci od 1 (najslabszy priorytet) do 3 (najwiekszy)
 * @author N.Materek
 * @version 1.1
 * @see MiniLog
 */
public enum Statement {
	INFO(1), WARNING(2), ERROR(3);
	private int priority;
	
	Statement(int priority){
		this.priority = priority;
	}
	
	/**
	 * @param stat 
	 * @return priority
	 * - priorytet wyliczenia podanego w arg
	 */
	static int getStatementValue(Statement stat){
		return stat.priority;
	}
	
}
