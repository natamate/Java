package pl.edu.agh.kis;

/**
 * 
 * @author N.Materek
 * @see MiniLog
 */
public interface Logs {

	public void addError(String stat);
	public void addInfo(String stat);
	public void addWarning(String stat);
	public void clear();
	public void setVisibility(int visibility);
	public int getVisibility();
	public void displayOnConsole();
	public void writeStatementToFile();
	public void readStatementFromFile();
}
