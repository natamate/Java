package pl.edu.agh.kis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Klasa przechowuje komunikaty w liscie, pozwalajac uzytkownikowi na ich
 * przeglad wg ustawionej widocznosci
 * 
 * @author N.Materek
 * @see Logs
 * @see ElementWithStatement
 */
public class MiniLog implements Logs {

	private List<ElementWithStatement> listOfStatements = new ArrayList<ElementWithStatement>();
	/**
	 * Ta zmienna odpowiada za kilka poziomow filtrowania komunikatow 0 -
	 * wszystkie komunikaty 1 - WARNING, ERROR 2 - ERROR 3 - nic Domyslnie 0
	 */
	private int visibility = 0;

	private String pathToFile;

	private MiniLog() {

	}

	public static Logs getLogsContainer(String pathToFile) {
		MiniLog m = new MiniLog();
		m.pathToFile = pathToFile;
		return m;
	}

	/**
	 * Dodaje Error do listy
	 * 
	 * @param stat
	 *             informacja do komunikatu
	 */
	public void addError(String stat) {
		ElementWithStatement element = new ElementWithStatement(
				Statement.ERROR, stat);
		listOfStatements.add(element);
	}

	/**
	 * Dodaje Info do listy
	 * 
	 * @param stat
	 *             informacja do komunikatu
	 */
	public void addInfo(String stat) {
		ElementWithStatement element = new ElementWithStatement(Statement.INFO,
				stat);
		listOfStatements.add(element);
	}

	/**
	 * Dodaje Warning do listy
	 * 
	 * @param stat
	 *             informacja do komunikatu
	 */
	public void addWarning(String stat) {
		ElementWithStatement element = new ElementWithStatement(
				Statement.WARNING, stat);
		listOfStatements.add(element);
	}
	
	/**
	 * Czysci wszystkie komunikaty, przed operacja zapisuje je do pliku znajdujacego
	 * sie w ustawionej pathToFile
	 */
	public void clear() {
		writeStatementToFile();
		listOfStatements.clear();
	}

	/**
	 * Modyfikacja widzialnosci
	 * @param visibility
	 *  nowa widzialnosc
	 */
	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}

	/**
	 * @return 
	 *  obecna widzialnosc
	 */
	public int getVisibility() {
		return visibility;
	}
	
	/**
	 * Ustawia sciezke pliku do ktorego zapisane beda komunikaty
	 * @param newPath nowa sciezka do pliku
	 */
	public void setPath(String newPath) {
		pathToFile = newPath;
	}

	/**
	 * 
	 * @return aktualna ustawiona sciezka
	 */
	public String getPath() {
		return pathToFile;
	}

	/**
	 * Wypisuje komunikaty na konsole uwzgledniajac ich widocznosc
	 */
	public void displayOnConsole() {
		for (ElementWithStatement e : listOfStatements) {
			if (e.getValueOfStatement() > visibility) {
				System.out.println(e);
			}
		}
	}

	public int getNumberOfParents(String path) {
		int counter = 0;
		for (int i = 0; i < path.length() - 1; i++) {
			if (path.charAt(i) == '/') {
				counter++;
			}
		}
		return counter;
	}
	
	/**
	 * Tworzy katalogi jesli nie istnieja
	 * @param file
	 *  plik 
	 */
	public void makePath(File file) {
		File fileParent;
		int counter = getNumberOfParents(pathToFile);
		if (file.getParent() != null && counter > 0) {
			fileParent = new File(file.getParent());
			if (fileParent.exists() == false) {
				if (fileParent.mkdirs()) {
					System.out.println("Utworzono katalog");
				} else {
					System.out.println("Nie utworzono katalogu");
				}
			}
			counter--;
		}
	}

	/**
	 * Zapisuje komunikaty do pliku (pathToFile)
	 * nastepnie czysci liste
	 * Jesli sciezka jest niepelna tworzy nowe katalogi
	 * @throws FileNotFoundException e
	 *   jesli nie znaleziono pliku
	 */
	public void writeStatementToFile() {
		File file = new File(pathToFile);

		makePath(file);

		try {
			PrintWriter out = new PrintWriter(file);
			for (ElementWithStatement e : listOfStatements) {
				if (e.getValueOfStatement() > visibility) {
					out.println(e);
				}
			}
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}

	/**
	 * Odczytuje komunikaty z pliku z pathToFile
	 * @throws IOException e
	 *  przy niepowodzeniu
	 */
	public void readStatementFromFile() {
		FileReader fr = null;
		String line = "";

		try {
			fr = new FileReader(pathToFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		BufferedReader br = new BufferedReader(fr);

		try {
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
