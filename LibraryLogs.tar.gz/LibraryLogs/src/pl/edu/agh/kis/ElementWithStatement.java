package pl.edu.agh.kis;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Pelny element log ktory zawiera 
 * statement - poziom loga, 
 * info - informacje zawarte w komunikacie,
 * dateOfBirth - date stworzenia loga 
 * @author N.Materek
 * @see Statement
 * @see MiniLog
 */

class ElementWithStatement{
	private Statement statement;
	private String info;
	private String dateOfBirth;
	
	ElementWithStatement(Statement statement, String info){
		this.statement = statement;
		this.info = info;
		dateOfBirth = getCurrentDate();
	}
	
	/**
	 * Zwraca aktualna date
	 * @return aktualna date w formacie("dd-MM-yyyy HH:mm:ss")
	 */
	public String getCurrentDate(){
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	/**
	 * 
	 * @return priorytet wyliczenia
	 */
	public int getValueOfStatement(){
		return Statement.getStatementValue(statement);
	}
	
	@Override
	public String toString(){
		return statement + " " + dateOfBirth + " " + info;
	}
}