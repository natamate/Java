package pl.edu.agh.kis;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class LibraryLogs{

	
	public static void main(String[] args) {
		
		Logs m = MiniLog.getLogsContainer("stat.txt");
		m.addError("Error 1");
		m.addInfo("Info 1");
		try{
			//arg w milisekundach
			Thread.sleep(2000);
		}catch(Exception e){
			e.printStackTrace();
		}
		m.addError("Error 2");
		m.addWarning("Warning 1");
		
		//m.setVisibility(2);
		
		m.displayOnConsole();
		m.writeStatementToFile();
		
		
		m.displayOnConsole();
	}

}