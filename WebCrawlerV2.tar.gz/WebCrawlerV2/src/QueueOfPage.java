import java.net.URL;

import javax.xml.crypto.Data;


public class QueueOfPage implements DownloadQueue{

	private static DateBase dateBase = new DataBaseOfPages("QUEUEPAGES");

	{
		dateBase.clear();
	}
	 public void addPage(URL pageURL){
		 String page = pageURL.toString();
		 dateBase.add(page);
	 }

	 public boolean isEmpty(){
		 if (getSize() == 0){
			 return true;
		 }
		 else{
			 return false;
		 }
	 }

	 public URL getNextPage(){
		 return dateBase.getNextPage();
	 }
	 
	 public int getSize(){
		 int size = 0;
		 size = dateBase.getSize();
		 return size;
	 }

}
