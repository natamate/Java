import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.h2.engine.Database;

import com.sun.xml.internal.fastinfoset.sax.Properties;

public class DataBaseOfPages implements DateBase {

	private static final String DB_URL = "jdbc:h2:tcp://localhost/~/testWebPages";
	private static final String DB_USER = "testWebPages";
	private static final String DB_PASSWD = "";
	private int id = 0;
	private String nameTable;

	public DataBaseOfPages(String newNameTable) {
		nameTable = newNameTable;
	}

	private static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("org.h2.Driver");

			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);

			System.out.println("Connected to database");
		} catch (Exception e) {
			System.out.println("Disconnected to database");
		}
		return conn;

	}

	public void add(String newPage) {
		insertPagesToBase(getConnection(), newPage);
	}

	public boolean contains(String searchPage) {
		if (isExist(getConnection(), searchPage) == true) {
			return true;
		} else {
			return false;
		}
	}

	public void clear() {
		for (int i = 0; i < numberOfVisitedPages(getConnection()); i++) {
		//for(int i = 0; i < 500; i++){
			removeWithId(getConnection(), i);
		}
	}

	public int getSize() {
		return numberOfVisitedPages(getConnection());
	}

	public URL getNextPage() {
		Connection dbConnection = getConnection();
		Statement stmt = null;
		String firstPage = "";
		try {
			stmt = dbConnection.createStatement();

			ResultSet result = stmt.executeQuery("SELECT * FROM QUEUEPAGES");
			result.next();
			firstPage = result.getString("page");
			int ID = result.getInt("id");
			removeWithId(dbConnection, ID);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		URL url = null;
		try {
			url = new URL(firstPage);
		} catch (Exception e) {
			System.out.println("Cannot convert to URL");
		}
		return url;
	}

	public static String getNowTime() {

		Calendar calendar = Calendar.getInstance();

		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"dd-MM-yyyy HH:mm:ss");
		dateFormat.format(calendar.getTime());

		StringBuffer date = new StringBuffer();
		date.append(calendar.get(Calendar.YEAR) + "-");
		date.append(calendar.get(Calendar.MONTH) + "-");
		date.append(calendar.get(Calendar.DAY_OF_MONTH) + " ");
		int tmp = 0;
		tmp = calendar.get(Calendar.HOUR_OF_DAY);
		if (tmp < 10) {
			date.append("0" + tmp + ":");
		} else {
			date.append(tmp + ":");
		}
		tmp = calendar.get(Calendar.MINUTE);
		if (tmp < 10) {
			date.append("0" + tmp + ":");
		} else {
			date.append(tmp + ":");
		}

		date.append(calendar.get(Calendar.SECOND) + ",");
		date.append(calendar.get(Calendar.MILLISECOND));

		return date.toString();
	}

	private void insertPagesToBase(Connection dbConnection, String newPages) {
		PreparedStatement stmt = null;
		try {
			stmt = dbConnection.prepareStatement("insert into " + nameTable
					+ " (ID, page, date) " + "values(?,?,?)");
			stmt.setInt(1, id++);
			stmt.setString(2, newPages);
			stmt.setString(3, getNowTime());

			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private boolean isExist(Connection dbConnection, String searchWebPage) {
		Statement stmt = null;
		try {
			stmt = dbConnection.createStatement();
			ResultSet result = stmt.executeQuery("SELECT * FROM " + nameTable);
			String page;
			while (result.next()) {
				page = result.getString("page");
				if (page.equals(searchWebPage)) {
					return true;
				}
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	private int numberOfVisitedPages(Connection dbConnection) {
		int result = 0;
		Statement stmt = null;
		try {
			stmt = dbConnection.createStatement();
			// System.out.println(nameTable);
			ResultSet rst = stmt.executeQuery("SELECT * FROM " + nameTable);
			while (rst.next()) {
				result++;
				// System.out.println(result);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	private void removeWithId(Connection dbConnection, int ID) {
		Statement stmt = null;
		try {
			stmt = dbConnection.createStatement();
			String sql = "DELETE FROM " + nameTable + " WHERE id =" + ID;
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private List<String> getListOfVisitedPages(Connection dbConnection) {
		List<String> resultList = new ArrayList<String>();
		Statement stmt = null;
		try {
			stmt = dbConnection.createStatement();
			ResultSet result = stmt.executeQuery("SELECT * FROM " + nameTable);
			while (result.next()) {
				resultList.add(result.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return resultList;
	}

	@Override
	public String toString() {
		StringBuffer result = new StringBuffer();
		for (String s : getListOfVisitedPages(getConnection())) {
			result.append(s + "\n");
		}
		return result.toString();
	}

}
