import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public class PageDownoader implements WWWPageDownloader {

	public String downloadPage(String pageURL) throws DownloaderException {

		StringBuilder result = new StringBuilder();

		try {
			URL oracle = new URL(pageURL);

			URLConnection dbConnection = oracle.openConnection();

			BufferedReader in = new BufferedReader(new InputStreamReader(
					dbConnection.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				result.append(inputLine + "\n");
			}

			in.close();
			BufferedReader stdin = new BufferedReader(new InputStreamReader(
					System.in));

		} catch (IOException e) {
			throw new DownloaderException(
					"IOException problem with your internet connection");
		} catch (Exception e) {
			throw new DownloaderException(
					"An incorrect URL or unpredictable error");
		}

		return result.toString();

	}

}
