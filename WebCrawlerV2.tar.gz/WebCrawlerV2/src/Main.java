
public class Main {

	public static void main(String[] args) {
		try{
			WebCrawlerV2 testCrawler = new WebCrawlerV2("http://www.onet.pl");
			testCrawler.start();
		}catch(DownloaderException e){
			System.out.println(e);
		}
		
		//DataBaseOfPages test = new DataBaseOfPages("VISITEDPAGES");
		//test.clear();
		
	}

}
