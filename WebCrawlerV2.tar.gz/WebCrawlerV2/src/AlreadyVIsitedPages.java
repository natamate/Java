import java.net.URL;


public class AlreadyVIsitedPages implements VisitedPages{
	DateBase dateBase = new DataBaseOfPages("VisitedPages");
	
	{
		dateBase.clear();
	}
	
	public boolean pageAlreadyVisited(URL pageURL){
		if (dateBase.contains(pageURL.toString()) == true){
			return true;
		}
		else{
			return false;
		}
			
	}

    public void addVisitedPage(URL pageURL){
    	if (pageAlreadyVisited(pageURL) == false){
    		dateBase.add(pageURL.toString());
    	}
    }

}
