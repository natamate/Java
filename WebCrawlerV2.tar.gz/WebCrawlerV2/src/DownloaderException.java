
public class DownloaderException extends Exception{

	String info;
	
	DownloaderException(String info){
		this.info = info;
	}
	
	public String notFindPage(){
		return "Page with the URL does not exist";
	}
	
	public String catchIO(){
		return "While retrieving the error occurred I / O - check your Internet connection";
	}
	
	public String Malformedurl(){
		return "Malformedurl Exception";
	}
	
	@Override
	public String toString(){
		return info;
	}

}
