import java.net.URL;

/**
 * Interfejs pozwalajacy na dostep do bazy danych, 
 * dodawanie do niej danych, 
 * weryfikacje danych w niej zawartych
 * @author N.M
 *
 */
public interface DateBase {
	public void add(String newPage);
	public boolean contains(String searchPage);
	public void clear();
	public int getSize();
	public URL getNextPage();
}
